/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA_Lab_10;

/**
 *
 * @author Muzamuil Ahmed
 */

  //Definition for a binary tree node.
  public class Tree_Node {
      int val;
      Tree_Node left;
      Tree_Node right;
      Tree_Node() {}
      Tree_Node(int val) { this.val = val; }
      Tree_Node(int val, Tree_Node left, Tree_Node right) {
          this.val = val;
          this.left = left;
          this.right = right;
      }
  }
 
class Solution {
    public boolean isSymmetric(Tree_Node root) {
        if(root==null) return true;
    return checksymmetric(root.left,root.right);
    }
    public static void main(String[] args) {
        System.out.println("working");
    }
    public boolean checksymmetric(Tree_Node left, Tree_Node right){
        if(left==null && right==null) return true;
        if(left==null || right==null || left.val !=right.val)return false;
        return checksymmetric(left.left,right.right)&& checksymmetric(left.right,right.left);
    }

    private static class TreeNode {

        public TreeNode() {
        }
    }
}