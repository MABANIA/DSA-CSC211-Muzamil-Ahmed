/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA_Lab_10;

/**
 *
 * @author Muzamuil Ahmed
 */
  public class Tree_Nodes {
      int val;
      Tree_Nodes left;
      Tree_Nodes right;
      Tree_Nodes() {}
      Tree_Nodes(int val) { this.val = val; }
      Tree_Nodes(int val, Tree_Nodes left, Tree_Nodes right) {
          this.val = val;
          this.left = left;
          this.right = right;
      }
      public static void main(String[] args) {
          System.out.println("working");
      }
  }
 
class Solution {
    public TreeNode invertTree(TreeNode root) {
      if (root == null) {
            return null;
        }
        
        TreeNode temp = root.left;
        root.left = root.right;
        root.right = temp;
        
        invertTree(root.left);
        invertTree(root.right);
        
        return root;        
  
    }
}
