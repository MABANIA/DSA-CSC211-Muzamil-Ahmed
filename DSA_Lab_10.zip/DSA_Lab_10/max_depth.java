/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA_Lab_10;

/**
 *
 * @author Muzamuil Ahmed
 */


// Definition for a binary tree node.
 
public class max_depth {
    int val;
    max_depth left;
    max_depth right;
    
    max_depth() {}
    max_depth(int val) { this.val = val; }
    max_depth(int val, max_depth left, max_depth right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }
}

class Solution {
    public int maxDepth(max_depth root) {
        if (root == null) return 0;
        int left = maxDepth(root.left);
        int right = maxDepth(root.right);
        return 1 + Math.max(left, right);
    }
}

 class Main {
    public static void main(String[] args) {
        System.out.println("working");
    }
}

