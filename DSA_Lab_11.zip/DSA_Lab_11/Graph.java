/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA_Lab_11;
import java.util.Scanner;
/**
 *
 * @author Muzamuil Ahmed
 */
public class Graph {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        System.out.print("Enter the number of nodes: ");
        int numNodes = inputScanner.nextInt();
        int[][] graphMatrix = new int[numNodes][numNodes];
        System.out.print("Enter the number of connections: ");
        int numEdges = inputScanner.nextInt();
        System.out.println("Enter the connections (u, v) pairs:");
        for (int i = 0; i < numEdges; i++) {
            int node1 = inputScanner.nextInt() - 1; // Convert to 0-based index
            int node2 = inputScanner.nextInt() - 1; // Convert to 0-based index
            graphMatrix[node1][node2] = 1; // Mark the edge in the matrix
        }

        System.out.println("Adjacency Matrix:");
        for (int i = 0; i < numNodes; i++) {
            for (int j = 0; j < numNodes; j++) {
                System.out.print(graphMatrix[i][j] + " ");
            }
            System.out.println();
        }

        inputScanner.close();
    }
}
