/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA_Lab_11;
import java.util.*;
/**
 *
 * @author Muzamuil Ahmed
 */



public class Shortest_path {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of nodes: ");
        int numNodes = sc.nextInt();
        
        int[][] graphMatrix = new int[numNodes][numNodes];

        System.out.print("Enter the number of connections: ");
        int numEdges = sc.nextInt();
        System.out.println("Enter the connections (u, v) pairs:");
        for (int i = 0; i < numEdges; i++) {
            int node1 = sc.nextInt() - 1; 
            int node2 = sc.nextInt() - 1; 
            graphMatrix[node1][node2] = 1;
            graphMatrix[node2][node1] = 1; 
        }

        System.out.print("Enter the source node: ");
        int source = sc.nextInt() - 1; 
        System.out.print("Enter the target node: ");
        int target = sc.nextInt() - 1; 

        
        computeShortestPath(graphMatrix, source, target, numNodes);
        sc.close();
    }

    public static void computeShortestPath(int[][] graph, int source, int target, int numNodes) {
        boolean[] visitedNodes = new boolean[numNodes]; 
        int[] parentNodes = new int[numNodes]; 
        Arrays.fill(parentNodes, -1); 
        Queue<Integer> nodeQueue = new LinkedList<>();

        visitedNodes[source] = true; 
        nodeQueue.add(source);

        while (!nodeQueue.isEmpty()) {
            int currentNode = nodeQueue.poll();

            if (currentNode == target) {
                displayPath(parentNodes, source, target);
                return;
            }

            for (int i = 0; i < numNodes; i++) {
                if (graph[currentNode][i] == 1 && !visitedNodes[i]) { 
                    visitedNodes[i] = true;
                    parentNodes[i] = currentNode; 
                    nodeQueue.add(i); 
                }
            }
        }
        System.out.println("No path exists.");
    }

    public static void displayPath(int[] parentNodes, int source, int target) {
        List<Integer> pathList = new ArrayList<>();
        for (int currentNode = target; currentNode != -1; currentNode = parentNodes[currentNode]) {
            pathList.add(currentNode + 1);
        }
        Collections.reverse(pathList);
        System.out.print("Shortest Path: ");
        System.out.println(String.join(" → ", pathList.stream().map(String::valueOf).toArray(String[]::new)));
        System.out.println("Length: " + (pathList.size() - 1));
    }
}
