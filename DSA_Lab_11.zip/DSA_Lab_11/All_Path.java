/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA_Lab_11;
import java.util.*;

/**
 *
 * @author Muzamuil Ahmed
 */
public class All_Path {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);

        System.out.print("Enter the number of nodes: ");
        int numNodes = inputScanner.nextInt();

        List<List<Integer>> graph = new ArrayList<>();
        for (int i = 0; i < numNodes; i++) {
            graph.add(new ArrayList<>());
        }

        System.out.print("Enter the number of connections: ");
        int numEdges = inputScanner.nextInt();
        System.out.println("Enter the connections (u, v) pairs:");
        for (int i = 0; i < numEdges; i++) {
            int node1 = inputScanner.nextInt() - 1;
            int node2 = inputScanner.nextInt() - 1;
            graph.get(node1).add(node2);
            graph.get(node2).add(node1);
        }

        System.out.print("Enter the starting node: ");
        int startNode = inputScanner.nextInt() - 1;
        System.out.print("Enter the destination node: ");
        int endNode = inputScanner.nextInt() - 1;

        List<List<Integer>> allPaths = new ArrayList<>();
        boolean[] visitedNodes = new boolean[numNodes];
        List<Integer> currentPath = new ArrayList<>();
        findAllPaths(graph, startNode, endNode, visitedNodes, currentPath, allPaths);

        System.out.println("Paths:");
        for (List<Integer> path : allPaths) {
            for (int i = 0; i < path.size(); i++) {
                System.out.print((path.get(i) + 1));
                if (i < path.size() - 1) {
                    System.out.print(" -> ");
                }
            }
            System.out.println(" (Length: " + (path.size() - 1) + ")");
        }

        inputScanner.close();
    }

    public static void findAllPaths(List<List<Integer>> graph, int currentNode, int endNode, boolean[] visitedNodes, List<Integer> currentPath, List<List<Integer>> allPaths) {
        visitedNodes[currentNode] = true;
        currentPath.add(currentNode);

        if (currentNode == endNode) {
            allPaths.add(new ArrayList<>(currentPath));
        } else {
            for (int neighbor : graph.get(currentNode)) {
                if (!visitedNodes[neighbor]) {
                    findAllPaths(graph, neighbor, endNode, visitedNodes, currentPath, allPaths);
                }
            }
        }

        visitedNodes[currentNode] = false;
        currentPath.remove(currentPath.size() - 1);
    }
}
