/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA_Lab_11;
import java.util.*;
/**
 *
 * @author Muzamuil Ahmed
 */
public class Connected_components{
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        System.out.print("Enter the number of nodes: ");
        int numNodes = inputScanner.nextInt();

        int[][] graphMatrix = new int[numNodes][numNodes];
        System.out.println("Enter the adjacency matrix (0 for no edge, 1 for edge):");
        for (int i = 0; i < numNodes; i++) {
            for (int j = 0; j < numNodes; j++) {
                graphMatrix[i][j] = inputScanner.nextInt();
            }
        }

        boolean[] visitedNodes = new boolean[numNodes]; 
        List<List<Integer>> connectedComponents = new ArrayList<>(); 

        for (int i = 0; i < numNodes; i++) {
            if (!visitedNodes[i]) { // If the node is not visited
                List<Integer> component = new ArrayList<>(); 
                performDFS(graphMatrix, visitedNodes, i, component); 
                connectedComponents.add(component); 
            }
        }

        System.out.println("Connected Components:");
        for (int i = 0; i < connectedComponents.size(); i++) {
            System.out.print("Component " + (i + 1) + ": {");
            for (int j = 0; j < connectedComponents.get(i).size(); j++) {
                System.out.print((connectedComponents.get(i).get(j) + 1)); 
                if (j < connectedComponents.get(i).size() - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println("}");
        }

        inputScanner.close();
    }

    public static void performDFS(int[][] graph, boolean[] visitedNodes, int currentNode, List<Integer> component) {
        visitedNodes[currentNode] = true; 
        component.add(currentNode); 

        for (int i = 0; i < graph.length; i++) {
            if (graph[currentNode][i] == 1 && !visitedNodes[i]) {
                performDFS(graph, visitedNodes, i, component); 
            }
        }
    }
}

