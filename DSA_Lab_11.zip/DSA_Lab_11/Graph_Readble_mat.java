/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA_Lab_11;
import java.util.Scanner;
/**
 *
 * @author Muzamuil Ahmed
 */

public class Graph_Readble_mat {

    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        System.out.print("Enter the number of nodes: ");
        int numNodes = inputScanner.nextInt();
        int[][] matrix = new int[numNodes][numNodes];
        System.out.print("Enter the number of connections: ");
        int numEdges = inputScanner.nextInt();
        System.out.println("Enter the connections (u, v) pairs:");
        for (int i = 0; i < numEdges; i++) {
            int node1 = inputScanner.nextInt() - 1; // Convert to 0-based index
            int node2 = inputScanner.nextInt() - 1; // Convert to 0-based index
            matrix[node1][node2] = 1; // Mark the edge in the matrix
        }
        printMatrix(matrix, numNodes);

        inputScanner.close();
    }

    public static void printMatrix(int[][] matrix, int numNodes) {
        System.out.println("Adjacency Matrix:");
        System.out.print("   ");
        for (int i = 1; i <= numNodes; i++) {
            System.out.print(i + " ");
        }
        System.out.println();

        for (int i = 0; i < numNodes; i++) {
            System.out.print((i + 1) + " ");
            for (int j = 0; j < numNodes; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }
}


