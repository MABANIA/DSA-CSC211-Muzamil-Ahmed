/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA_Lab_09;

/**
 *
 * @author Muzamuil Ahmed
 */
class NodeElement {
    int key;
    NodeElement leftBranch, rightBranch;

    NodeElement(int key) {
        this.key = key;
        leftBranch = rightBranch = null;
    }
}
public class new_Binary_Tree {
    NodeElement mainNode;

    void add(int key) {
        mainNode = addRecursive(mainNode, key);
    }

    NodeElement addRecursive(NodeElement mainNode, int key) {
        if (mainNode == null) {
            mainNode = new NodeElement(key);
            return mainNode;
        }
        if (key < mainNode.key) {
            mainNode.leftBranch = addRecursive(mainNode.leftBranch, key);
        } else if (key > mainNode.key) {
            mainNode.rightBranch = addRecursive(mainNode.rightBranch, key);
        }
        return mainNode;
    }

    int getNodeCount() {
        return countNodesRecursive(mainNode);
    }

    int countNodesRecursive(NodeElement mainNode) {
        if (mainNode == null) {
            return 0;
        }
        return 1 + countNodesRecursive(mainNode.leftBranch) + countNodesRecursive(mainNode.rightBranch);
    }

    void traverseInOrder() {
        inOrderRecursive(mainNode);
        System.out.println();
    }

    void inOrderRecursive(NodeElement mainNode) {
        if (mainNode != null) {
            inOrderRecursive(mainNode.leftBranch);
            System.out.print(mainNode.key + " ");
            inOrderRecursive(mainNode.rightBranch);
        }
    }

    void traversePreOrder() {
        preOrderRecursive(mainNode);
        System.out.println();
    }

    void preOrderRecursive(NodeElement mainNode) {
        if (mainNode != null) {
            System.out.print(mainNode.key + " ");
            preOrderRecursive(mainNode.leftBranch);
            preOrderRecursive(mainNode.rightBranch);
        }
    }

    void traversePostOrder() {
        postOrderRecursive(mainNode);
        System.out.println();
    }

    void postOrderRecursive(NodeElement mainNode) {
        if (mainNode != null) {
            postOrderRecursive(mainNode.leftBranch);
            postOrderRecursive(mainNode.rightBranch);
            System.out.print(mainNode.key + " ");
        }
    }

    public static void main(String[] args) {
        new_Binary_Tree tree = new new_Binary_Tree();
        tree.add(30);
        tree.add(45);
        tree.add(10);
        tree.add(7);
        tree.add(25);
        tree.add(35);
        tree.add(55);
        System.out.println("In-Order Traversal: ");
        tree.traverseInOrder();
        System.out.println("Pre-Order Traversal: ");
        tree.traversePreOrder();
        System.out.println("Post-Order Traversal: ");
        tree.traversePostOrder();
        System.out.println("Total Nodes in the Tree: ");
        System.out.println(tree.getNodeCount());
    }
}