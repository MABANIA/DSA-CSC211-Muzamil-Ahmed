/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA_LAB_07_and_08;

/**
 *
 * @author Muzamuil Ahmed
 */
class TreeNode {
    int value;
    TreeNode leftChild;
    TreeNode rightChild;

    public TreeNode(int value) {
        this.value = value;
        leftChild = null;
        rightChild = null;
    }
}

// Binary Tree class with traversal methods
class BinaryTreeStructure {
    TreeNode mainRoot;

    // Constructor
    public BinaryTreeStructure() {
        mainRoot = null;
    }

    // Insert node into the binary tree
    public void addValue(int value) {
        mainRoot = addTreeNode(mainRoot, value);
    }

    // Helper method to insert node recursively
    private TreeNode addTreeNode(TreeNode currentNode, int value) {
        if (currentNode == null) {
            currentNode = new TreeNode(value);
            return currentNode;
        }

        if (value < currentNode.value) {
            currentNode.leftChild = addTreeNode(currentNode.leftChild, value);
        } else if (value > currentNode.value) {
            currentNode.rightChild = addTreeNode(currentNode.rightChild, value);
        }

        return currentNode;
    }

    // Inorder Traversal (Left-Root-Right)
    public void inorderTraversal(TreeNode currentNode) {
        if (currentNode != null) {
            inorderTraversal(currentNode.leftChild);
            System.out.print(currentNode.value + " ");
            inorderTraversal(currentNode.rightChild);
        }
    }

    // Preorder Traversal (Root-Left-Right)
    public void preorderTraversal(TreeNode currentNode) {
        if (currentNode != null) {
            System.out.print(currentNode.value + " ");
            preorderTraversal(currentNode.leftChild);
            preorderTraversal(currentNode.rightChild);
        }
    }

    // Postorder Traversal (Left-Right-Root)
    public void postorderTraversal(TreeNode currentNode) {
        if (currentNode != null) {
            postorderTraversal(currentNode.leftChild);
            postorderTraversal(currentNode.rightChild);
            System.out.print(currentNode.value + " ");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        BinaryTreeStructure treeStructure = new BinaryTreeStructure();

        // Insert nodes into the binary tree
        treeStructure.addValue(10);
        treeStructure.addValue(50);
        treeStructure.addValue(1);
        treeStructure.addValue(15);
        treeStructure.addValue(200);
//        treeStructure.addValue(25);
//        treeStructure.addValue(5);
//        treeStructure.addValue(9);
//        treeStructure.addValue(18);

        System.out.println("Inorder Traversal:");
        treeStructure.inorderTraversal(treeStructure.mainRoot);

        System.out.println("\n\nPreorder Traversal:");
        treeStructure.preorderTraversal(treeStructure.mainRoot);

        System.out.println("\n\nPostorder Traversal:");
        treeStructure.postorderTraversal(treeStructure.mainRoot);
    }
}
