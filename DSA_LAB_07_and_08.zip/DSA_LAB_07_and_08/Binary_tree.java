/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA_LAB_07_and_08;

/**
 *
 * @author Muzamuil Ahmed
 */

class TreeNode {
    int value;
    TreeNode rightChild;
    TreeNode leftChild;

    TreeNode(int value) {
        this.value = value;
        rightChild = null;
        leftChild = null;
    }
}

class BinaryTreeExample {
    TreeNode rootNode;

    BinaryTreeExample() {
        this.rootNode = null;
    }

    public void addNode(int value) {
        rootNode = addTreeNode(rootNode, value);
    }

    public TreeNode addTreeNode(TreeNode current, int value) {
        if (current == null) {
            current = new TreeNode(value);
            return current;
        }
        if (value < current.value) {
            current.leftChild = addTreeNode(current.leftChild, value);
        } else if (value > current.value) {
            current.rightChild = addTreeNode(current.rightChild, value);
        }
        return current;
    }

    public void inorderTraversal(TreeNode current) {
        if (current != null) {
            inorderTraversal(current.leftChild);
            System.out.println(current.value + " ");
            inorderTraversal(current.rightChild);
        }
    }

    public void preorderTraversal(TreeNode current) {
        if (current != null) {
            System.out.println(current.value + " ");
            preorderTraversal(current.leftChild);
            preorderTraversal(current.rightChild);
        }
    }

    public void postorderTraversal(TreeNode current) {
        if (current != null) {
            postorderTraversal(current.leftChild);
            postorderTraversal(current.rightChild);
            System.out.println(current.value + " ");
        }
    }
}

public class Binary_tree {
    public static void main(String[] args) {
        BinaryTreeExample tree = new BinaryTreeExample();
        tree.addNode(7);
        tree.addNode(50);
        tree.addNode(2);
        tree.addNode(18);
        tree.addNode(120);

        System.out.println("Inorder traversal: ");
        tree.inorderTraversal(tree.rootNode);

        System.out.println("Preorder traversal: ");
        tree.preorderTraversal(tree.rootNode);

        System.out.println("Postorder traversal: ");
        tree.postorderTraversal(tree.rootNode);
    }
}
